import com.zensar.pack1.Student;
import com.zensar.pack2.Batch;
import static com.zensar.pack2.Batch.fun;

public class Test {
	public static void main(String args[])
	{
		Student student=new Student();
		Batch batch=new Batch();
		Batch.fun();
		
	}

}
