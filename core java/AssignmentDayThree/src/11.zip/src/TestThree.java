// Main class for que 6
import com.zensar.SalesPerson;
import com.zensar.WageEmployee;;

public class TestThree{
	public static void main(String args[])
	{
		SalesPerson w1=new SalesPerson(3,"ABCD",12,3,2001,13,5,15,2);
		w1.display();
		w1.salarySalesEmp();
		w1.salaryWageEmp();
	}

}

