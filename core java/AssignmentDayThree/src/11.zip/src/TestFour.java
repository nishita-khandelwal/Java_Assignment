import com.zensar.Manager;
import com.zensar.MarketingExecutive;

//main class of que 7
public class TestFour {
	public static void main(String args[])
	{
		MarketingExecutive marketingExecutive=new MarketingExecutive(111,"Akshay",10000,20);
		Manager manager=new Manager(112,"Jack",12000);
		marketingExecutive.GrossSalaryME();
		marketingExecutive.NetSalaryMS();
		marketingExecutive.display();
		marketingExecutive.display2();
		manager.GrossSalaryM();
		manager.NetSalaryM();
		manager.display1();
		
	}

}
