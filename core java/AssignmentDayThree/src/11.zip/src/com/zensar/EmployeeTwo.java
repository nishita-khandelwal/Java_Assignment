package com.zensar;

public class EmployeeTwo {
	private int empid;
	private String name;
	private double basicSalary;
	
	
	public EmployeeTwo() {
		super();
	}
	public EmployeeTwo(int empid, String name, double basicSalary) {
		super();
		this.empid = empid;
		this.name = name;
		this.basicSalary = basicSalary;
	}
	public double getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(double basicSalary) {
		this.basicSalary = basicSalary;
	}
	public void display()
	{
		System.out.println("Empid is:-"+empid+" Name is:-"+name+" and Salary is"+basicSalary);
	}
}
